window.onload = function () {
    let stage = $("#stage");
    let p1 = new Player1();
    let p2 = new Player2();
    // 事件监听
    window.onkeydown = function (e) {
        p1.move(e.keyCode);
        p2.move(e.keyCode);
        p1.skills(e.keyCode);
        p2.skills(e.keyCode);
        p1.downBlood(p2, e.keyCode);
        p2.downBlood(p1, e.keyCode);
    }
    window.onkeyup = function (e) {
        p1.clearAnimate(e.code);
        p2.clearAnimate(e.code);
    }

}

// 选择器
function $(node) {
    let el = document.querySelectorAll(node);
    if (el.length > 1) return el;
    if (el.length == 1) return el[0];
}


// 玩家1
function Player1(opt) {
    this.name = 'P1'; //用户名
    this.blood = 100; //血量
    this.x = 100; //初始坐标
    this.body = ''; //身体dom
    this.speed = 10; //移动速度
    this.atkNum = 1; //攻击力
    this.atkDistance = 10; //攻击距离
    this.nameDom = '';
    this.bloodDom = ''
    this.skill1Dom = '';
    this.skill2Dom = '';
    this.direction = {
        'left': false,
        'right': false,
    } //记录当前方向，以便位移技能判定方向
    let _this = this;
    let atk1Timer, atk2Timer, skill1Timer, skill2Timer;
    let dTimerL, dTimerR;
    //替换参数
    if (opt) {
        if (opt.name) this.name = opt.name;
        if (opt.blood) this.blood = opt.blood;
    }

    // 创建playerDom
    this.create = function () {
        //创建身体
        _this.body = document.createElement('div');
        _this.body.setAttribute('class', 'player');
        _this.body.style.left = _this.x + 'px';
        //创建名字
        _this.nameDom = document.createElement('div');
        _this.nameDom.setAttribute('class', 'playerName');
        _this.nameDom.innerHTML = _this.name;
        //创建血条
        _this.bloodDom = document.createElement('div');
        _this.bloodDom.setAttribute('class', 'playerBlood');
        //创建血量
        _this.bloodBarDom = document.createElement('div');
        _this.bloodBarDom.setAttribute('class', 'playerBloodBar');
        _this.bloodBarDom.style.width = _this.blood + '%';

        //创建技能一
        _this.skill1Dom = document.createElement('div');
        _this.skill1Dom.setAttribute('class', 'playerSkill1');
        //创建技能二
        _this.skill2Dom = document.createElement('div');
        _this.skill2Dom.setAttribute('class', 'playerSkill2');


        //dom加入
        _this.body.appendChild(_this.nameDom);
        _this.bloodDom.appendChild(_this.bloodBarDom);
        _this.body.appendChild(_this.bloodDom);
        _this.body.appendChild(_this.skill1Dom);
        _this.body.appendChild(_this.skill2Dom);
        stage.appendChild(_this.body);
    }


    //移动
    this.move = function (code) {
        // a 65 
        if (code == 65) {
            _this.direction.left = true;
            clearInterval(dTimerL);
            dTimerL = setInterval(function () {
                _this.direction.left = false;
            }, 500)
            //左界限
            if (_this.x <= 40) {
                _this.x = 40;
            }
            _this.body.style.transform = 'rotateY(180deg)'
            _this.nameDom.style.transform = 'rotateY(180deg)'
            _this.bloodDom.style.transform = 'rotateY(180deg)'
            _this.body.style.animation = 'playerRun .5s infinite';
            _this.x -= _this.speed;
            _this.body.style.left = _this.x + 'px';
        }
        // d 68
        if (code == 68) {
            _this.direction.right = true;
            clearInterval(dTimerR);
            dTimerR = setInterval(function () {
                _this.direction.right = false;
            }, 500)
            //右界限
            if (_this.x >= 900) {
                _this.x = 900;
            }
            _this.body.style.transform = 'rotateY(0deg)'
            _this.nameDom.style.transform = 'rotateY(0deg)'
            _this.bloodDom.style.transform = 'rotateY(0deg)'
            _this.body.style.animation = 'playerRun .5s infinite';
            _this.x += _this.speed;
            _this.body.style.left = _this.x + 'px';
        }
    }

    // 技能
    this.skills = function (code) {
        //普通攻击1
        if (code == 74) {
            _this.body.style.animation = 'playerAtk1 1s infinite';
            console.log(code);
            clearInterval(atk1Timer);
            atk1Timer = setInterval(function () {
                _this.body.style.animation = '';
            }, 1000)
        }
        //位移
        if (code == 76) {
            let s_speed = 100; //位移距离
            if (_this.direction.left) {
                _this.x -= s_speed;
                _this.body.style.left = _this.x + 'px';
            }
            if (_this.direction.right) {
                _this.x += s_speed;
                _this.body.style.left = _this.x + 'px';
            }
        }

        //普通攻击2
        if (code == 75) {
            clearInterval(atk2Timer);
            atk2Timer = setInterval(function () {
                _this.body.style.animation = '';
            }, 1500);
            _this.body.style.animation = 'playerAtk2 1.5s';
        }

        //技能一 
        if (code == 85) {
            clearInterval(skill1Timer);
            skill1Timer = setInterval(function () {
                _this.skill1Dom.style.animation = '';
            }, 1000);
            _this.skill1Dom.style.animation = 'playerSkill1 1s infinite';
        }
        //技能二 
        if (code == 73) {
            clearInterval(skill2Timer);
            skill2Timer = setInterval(function () {
                _this.skill2Dom.style.animation = '';
            }, 1000);
            _this.skill2Dom.style.animation = 'playerSkill2 1s infinite';
        }
    }

    this.clearAnimate = function (code) {
        if (code == 'KeyA' || code == 'KeyD') {
            _this.body.style.animation = 'none';

        }
    }

    this.downBlood = function (atker, code) {
        if (code == 97 || code == 98 || code == 100 || code == 101) {
            _this.blood -= atker.atkNum;
            _this.bloodBarDom.style.width = _this.blood + '%';
        }
    }


    this.create();

}



// 玩家2
function Player2(opt) {
    this.name = 'P2'; //用户名
    this.blood = 100; //血量
    this.x = 1000; //初始坐标
    this.body = ''; //身体dom
    this.speed = 10; //移动速度
    this.atkNum = 1; //攻击力
    this.atkDistance = 10; //攻击距离
    this.skill3Dom = '';
    this.skill4Dom = '';
    this.direction = {
        'left': false,
        'right': false,
    } //记录当前方向，以便位移技能判定方向
    let _this = this;
    let atk1Timer, atk2Timer, skill3Timer, skill4Timer;
    let dTimerL, dTimerR;
    //替换参数
    if (opt) {
        if (opt.name) this.name = opt.name;
        if (opt.blood) this.blood = opt.blood;
    }

    // 创建playerDom
    this.create = function () {
        //创建身体
        _this.body = document.createElement('div');
        _this.body.setAttribute('class', 'player2');
        _this.body.style.left = _this.x + 'px';
        _this.body.style.transform = 'rotateY(180deg)'
        //创建名字
        _this.nameDom = document.createElement('div');
        _this.nameDom.setAttribute('class', 'playerName');
        _this.nameDom.innerHTML = _this.name;
        _this.nameDom.style.transform = 'rotateY(180deg)'
        //创建血条
        _this.bloodDom = document.createElement('div');
        _this.bloodDom.setAttribute('class', 'playerBlood');
        _this.bloodDom.style.transform = 'rotateY(180deg)'
        //创建血量
        _this.bloodBarDom = document.createElement('div');
        _this.bloodBarDom.setAttribute('class', 'playerBloodBar2');
        _this.bloodBarDom.style.width = _this.blood + '%';
        //创建技能三
        _this.skill3Dom = document.createElement('div');
        _this.skill3Dom.setAttribute('class', 'playerSkill3');
        //创建技能四
        _this.skill4Dom = document.createElement('div');
        _this.skill4Dom.setAttribute('class', 'playerSkill4');

        //dom加入
        _this.body.appendChild(_this.nameDom);
        _this.bloodDom.appendChild(_this.bloodBarDom);
        _this.body.appendChild(_this.bloodDom);
        _this.body.appendChild(_this.skill3Dom);
        _this.body.appendChild(_this.skill4Dom);
        stage.appendChild(_this.body);
    }


    //移动
    this.move = function (code) {
        // 左 37
        if (code == 37) {
            _this.direction.left = true;
            clearInterval(dTimerL);
            dTimerL = setInterval(function () {
                _this.direction.left = false;
            }, 500)
            //左界限
            if (_this.x <= 40) {
                _this.x = 40;
            }
            _this.body.style.transform = 'rotateY(180deg)'
            _this.nameDom.style.transform = 'rotateY(180deg)'
            _this.bloodDom.style.transform = 'rotateY(180deg)'
            _this.body.style.animation = 'playerRun .5s infinite';
            _this.x -= _this.speed;
            _this.body.style.left = _this.x + 'px';
        }
        // 右 38
        if (code == 39) {
            _this.direction.right = true;
            clearInterval(dTimerR);
            dTimerR = setInterval(function () {
                _this.direction.right = false;
            }, 500)
            //右界限
            if (_this.x >= 900) {
                _this.x = 900;
            }
            _this.body.style.transform = 'rotateY(0deg)'
            _this.nameDom.style.transform = 'rotateY(0deg)'
            _this.bloodDom.style.transform = 'rotateY(0deg)'
            _this.body.style.animation = 'playerRun .5s infinite';
            _this.x += _this.speed;
            _this.body.style.left = _this.x + 'px';
        }
    }

    // 技能
    this.skills = function (code) {
        //普通攻击1
        if (code == 97) {
            _this.body.style.animation = 'playerAtk1 1s infinite';
            clearInterval(atk1Timer);
            atk1Timer = setInterval(function () {
                _this.body.style.animation = '';
            }, 1000)
        }
        //位移
        if (code == 99) {
            let s_speed = 100; //位移距离
            if (_this.direction.left) {
                _this.x -= s_speed;
                _this.body.style.left = _this.x + 'px';
            }
            if (_this.direction.right) {
                _this.x += s_speed;
                _this.body.style.left = _this.x + 'px';
            }
        }

        //普通攻击2
        if (code == 98) {
            clearInterval(atk2Timer);
            atk2Timer = setInterval(function () {
                _this.body.style.animation = '';
            }, 1500);
            _this.body.style.animation = 'playerAtk2 1.5s';
        }

        //技能一 
        if (code == 100) {
            clearInterval(skill3Timer);
            skill3Timer = setInterval(function () {
                _this.skill3Dom.style.animation = '';
            }, 1000);
            _this.skill3Dom.style.animation = 'playerSkill3 1s infinite';
        }
        //技能二 
        if (code == 101) {
            clearInterval(skill4Timer);
            skill4Timer = setInterval(function () {
                _this.skill4Dom.style.animation = '';
            }, 1000);
            _this.skill4Dom.style.animation = 'playerSkill4 1s infinite';
        }
    }

    this.clearAnimate = function (code) {
        if (code == 'ArrowLeft' || code == 'ArrowRight') {
            _this.body.style.animation = 'none';

        }
    }

    this.downBlood = function (atker, code) {
        if (code == 74 || code == 75 || code == 85 || code == 73) {
            _this.blood -= atker.atkNum;
            _this.bloodBarDom.style.width = _this.blood + '%';
        }
    }


    this.create();

}